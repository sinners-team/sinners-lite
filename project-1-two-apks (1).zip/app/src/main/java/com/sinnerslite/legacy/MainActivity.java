package com.sinnerslite.legacy;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.HashMap;
import java.util.Map;

/** Sinners Lite: a thin shell around https://sinlite.pages.dev for Android 5.0 and newer. */
public class MainActivity extends Activity {

    private static final String HOME = "https://sinlite.pages.dev/";
    private static final int FILE_REQ = 1001;

    private WebView web;
    private ValueCallback<Uri[]> filePath;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        web = new WebView(this);
        web.setBackgroundColor(0xFFFDF0D3);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        if (BuildConfig.DATA_SAVER) {
            // Data saver: reuse cached files whenever possible and tell the server to send lighter pages.
            s.setCacheMode(WebSettings.LOAD_DEFAULT);
        }

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handle(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handle(request.getUrl().toString());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePath != null) {
                    filePath.onReceiveValue(null);
                }
                filePath = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQ);
                } catch (ActivityNotFoundException e) {
                    filePath = null;
                    return false;
                }
                return true;
            }
        });

        if (state == null) {
            Map<String, String> h = new HashMap<>();
            if (BuildConfig.DATA_SAVER) h.put("Save-Data", "on");
            web.loadUrl(HOME, h);
        } else {
            web.restoreState(state);
        }
    }

    /** Keep our own site and sign-in pages inside the app; send everything else to the phone. */
    private boolean handle(String url) {
        Uri u = Uri.parse(url);
        String scheme = u.getScheme();
        if (scheme == null) return false;
        if (scheme.equals("about") || scheme.equals("blob") || scheme.equals("data")
                || scheme.equals("javascript")) return false;
        String host = u.getHost();
        if (scheme.equals("https") && host != null && isInternal(host)) return false;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception ignored) {
        }
        return true;
    }

    private boolean isInternal(String h) {
        return h.equals("sinlite.pages.dev") || h.endsWith(".sinlite.pages.dev")
                || h.endsWith(".firebaseapp.com") || h.equals("accounts.google.com")
                || h.endsWith(".googleapis.com");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQ) {
            if (filePath != null) {
                filePath.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePath = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }
}
